# PALIMPSEST results bundle
Run date: 2026-08-29 03:37
Data mode: balancing authority = real, Low Carbon London = real
Balancing authority: CISO   years: 2016â€“2024   accuracy holdout from 2023-01-01
Flex Alert holdout: alert days after 2021 (10 days)

## Contents
fig_pipeline.png                     pipeline / architecture diagram
fig_thermal.png                      thermal layer fit and residual by hour
fig_behavioral.png                   identified vs ablation behavioral coefficients (+ ground truth if synthetic)
fig_central_flex_alert_holdout.png   CENTRAL FIGURE: implied vs observed appeal effect on held-out Flex Alert days
fig_covid_holdout.png                lockdown holdout weekday profiles
fig_lcl.png                          Low Carbon London ToU response and weather dependence
fig_interactive_example.png          example counterfactual (+3 C with appeal) with decomposition and analogs
counterfactual_example_hourly.csv    hourly table behind that example
results.json                         all headline metrics
tables/                              every result table as CSV (Aâ€“E), coefficients, parameters, daily features
images/                              technology photographs used in the notebook header, with CREDITS.md

## Headline numbers
[A] accuracy
                           MAPE  pinball10  pinball50  pinball90  coverage80
model                                                                       
PALIMPSEST (identified)   3.790    255.872    479.356    224.555      64.949
Ablation (full-series)    3.752    257.534    474.015    218.891      65.765
Flag-as-feature LGBM      2.872    180.047    359.876    169.724      72.024
Plain LGBM                2.851    181.239    356.784    170.296      71.499
Persistence (lag 168h)    6.816        NaN    896.948        NaN         NaN
Similar-day (kNN analog)  6.080        NaN    763.917        NaN         NaN

[B] Flex Alert interventional holdout
            n_days  bias_pp  MAE_pp  MAE_lo  MAE_hi  RMSE_pp  window_MAPE  window_coverage80
model                                                                                       
identified      10    3.685   6.362   4.051   8.783    8.725        5.258               56.0
ablation        10    4.045   6.426   4.069   8.894    8.867        5.341               50.0
flagfeat        10    4.011   6.091   3.748   8.540    8.604        4.705               64.0
plain           10    2.243   6.118   4.039   8.285    8.091        5.469               44.0

[C] COVID holdout
                                         MAPE  bias_pct  coverage80
model                                                              
PALIMPSEST (identified)                 2.548    -1.119      85.326
Ablation (full-series)                  2.358     0.062      87.953
Flag-as-feature LGBM                    3.229     1.387      73.188
Plain LGBM                              3.590     2.394      68.025
Structural only, identified occupancy   5.129     0.843         NaN
Structural only, no occupancy term     10.015     9.407         NaN

[D] Low Carbon London
                                             MAPE_all  MAPE_peak
model                                                           
Counterfactual with identified ToU response    24.785     26.152
No behavioral term (B â‰ˆ control)             27.734     23.994
